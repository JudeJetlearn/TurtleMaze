game = ["Roblox","Minecraft","GAG"]

while True:
    print("1) Show List")
    print("2) Add Game From List")
    print("3) Remove Game From List")
    print("4) Exit List")
    option = int(input("Pick an option."))

    if option == 1 :
        print(game)
    if option == 2 :
        added = input("Add The Game.")
        game.append(added)
    if option == 3 :
        remove = input("Pick The Game to Remove.")
        game.remove(remove)
    if option == 4 :
        break