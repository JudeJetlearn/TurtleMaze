import random

grid = []

def TresureHunt():

    global lives, x, y
        
    lives = 5
    x = random.randint(0,4) #collum
    y = random.randint(0,4) #row

    for i in range(5):
        subgrid = []
        for j in range(5):
            subgrid.append("-")
        grid.append(subgrid)

    for i in grid:
        print(
            " ".join(i)
        )

    print("Welcome to Tresure Hunt! Enter a guess for the Tresure. ")
    print(f"You have {lives} attempts.")

lives = 5
x = random.randint(0,4) #collum
y = random.randint(0,4) #row

TresureHunt()

while True:

    print()
    try:
        guessCollum = int(input("Enter the Collum Number (0-4): "))
        guessRow = int(input("Enter the Row Number (0-4): "))
        
        if guessRow < 0 or guessRow > 4 or  guessCollum < 0 or  guessCollum > 4:
            raise ValueError("Position out of Grid! (0-4 ONLY!)")

        print(f"{guessCollum}{","}{guessRow}")

        if x != guessCollum or y != guessRow:
                grid[guessRow][guessCollum] = "X"
                lives = lives -1
            
    except ValueError:
        print(f"Invalid input!")
        print(f"Dont worry! You still have {lives} attempts.")
        continue

    if guessRow == x and guessCollum == y :

        print("Welldone you found the tresure! at "f"{x}{","}{y} !")

        grid[guessRow][guessCollum] = "💎"

        for i in grid:
            print(
                " ".join(i)
            )

        play = input("Do you want to play again? Y/N ").upper()
        
        if play == "Y" :
            TresureHunt()
        elif play == "N" :
            break
        else:
            play = input("Do you want to play again? Y/N ").upper()

    for i in grid:
        print(
            " ".join(i)
        )

    if guessRow > x :
        print("Hint! Go up.")
    if guessRow < x :
        print("Hint! Go down.")
    if guessCollum > y :
        print("Hint! Go left.")
    if guessCollum < y :
        print("Hint! Go right.")

    print(f"You have {lives} attempts.")

    if lives == 0:
        print(f"You have Ran out of attempts! The tresure was at {x}{","}{y}.")

        play = input("Do you want to play again? Y/N ").upper()

        if play == "Y" :
            grid = []
            TresureHunt()
        elif play == "N" :
            break
        else:
            play = input("Do you want to play again? Y/N ").upper()

