import random

Words = [
    "Amulet", "Asteroid", "Badger", "Basket", "Bicycle", "Blanket", "Blizzard", 
    "Bounce", "Breeze", "Bucket", "Button", "Cactus", "Camera", "Candle", 
    "Canyon", "Castle", "Chatter", "Cheese", "Clatter", "Coding", "Compass", 
    "Crystal", "Cushion", "Cyborg", "Cyclone", "Deceive", "Dragon", "Drift", 
    "Eclipse", "Feather", "Forest", "Freeze", "Galaxy", "Giggle", "Glacier", 
    "Glance", "Goblin", "Gossip", "Grumble", "Guitar", "Hammer", "Jacket", 
    "Juggle", "Jumble", "Keyhole", "Kingdom", "Kitchen", "Lantern", "Laser", 
    "Laughter", "Levitate", "Lizard", "Meadow", "Meteor", "Mirror", "Mutant", 
    "Newcomer", "Ocean", "Orchard", "Pancake", "Pathway", "Pebble", "Pencil", 
    "Playful", "Polishing", "Portal", "Potion", "Puzzle", "Quiver", "Robot", 
    "Rocket", "Runaway", "Scatter", "Scramble", "Shield", "Skater", "Sketch", 
    "Snooze", "Spaceship", "Spoon", "Sprint", "Stroll", "Summit", "Swamp", 
    "Thunder", "Tickle", "Toaster", "Tome", "Treasure", "Trinket", "Tumble", 
    "Vanishing", "Volcano", "Voyage", "Wallet", "Waterfall", "Whisper", "Wildcard", 
    "Willow", "Window", "Wizard", "X-ray", "Xenon", "Xylophone", "Yacht", 
    "Yarn", "Year", "Yellow", "Young", "Zebra", "Zero", "Zipper", "Zone"
]


def WordJumbler():

    Word = random.choice(Words)
    Letters = Word
    Letter1 = Word

    Letters = list(Letters)
    random.shuffle(Letters)
    Jumbled = " ".join(Letters)

    Letter1 = list(Letter1)
    Letter1 = Letter1[0].upper()

    return Word, Jumbled, Letter1

while True:

    Word, Jumbled, Letter1 = WordJumbler()
    Score = 0
    Round = 1

    print("Welcome to the Advanced Word Jumble Game!")
    print("")

    for i in range(5):

        print(f"Round {Round}:")
        print(f"Here is the scrambled word: {Jumbled}")

        hint = str(input("Do you want a hint? (Y/N): ")).upper()

        while hint != "Y" and hint != "N":
            hint = str(input("Invalid input. Do you want a hint? (Y/N): ")).upper()

        if hint == "Y":
            print(f"The first Letter of the word is {Letter1}.")

        guess = str(input("Guess the original word: ")).lower()
        if guess == Word:
            print("Congratulations! You guessed it right!")
            Score = Score + 1
        else:
            print(f"Inncorret! The word was {Word}.")

        Round =  Round + 1
        print(f"Your score is now: {Score}")
        Word, Jumbled, Letter1 = WordJumbler()
        print("")

    print(f"Your got {Score}/5 questions right!")
    if Score == 0:
        print("Can you please try the game or are you just that bad?")
    if Score > 0 and Score < 3:
        print("Not Bad! But you can do better!")
    if Score > 2 and Score < 5:
        print("Good Job! Play again to get Perfect score")
    if Score == 5:
        print("WOW! A PERFECT SCORE! You are Brilliant!")
    print("")
        
    game = str(input("Do you want to play again? (Y/N): ")).upper()
    while game != "Y" and game != "N":
        game = input("Invalid input! Play again? (Y/N): ").upper()

    if game == "N":
        print("Thanks for Playing!")
        break
