def CelsiusToFahrenheit(Celsius):
    return (Celsius*1.8) + 32

def FahrenheitToCelsius(Fahrenheit):
    return (Fahrenheit - 32) / 1.8

def CelsiusToKelvin(Celsius):
    return Celsius + 273.15


while True :
    print("1) Convert Celsius to Fahrenheit. ")
    print("2) Convert Fahrenheit to Celsius. ")
    print("3) Convert Celsius to Kelvin. ")

    opition = int(input("Pick a Temperature Conversion. "))

    if opition == 1 :
        Celsius = float(input("How much Celsius? "))
        print(str(CelsiusToFahrenheit(Celsius))+"°F (Fahrenheit)")

    if opition == 2 :
        Fahrenheit = float(input("How much Fahrenheit? "))
        print(str(FahrenheitToCelsius(Fahrenheit))+"°C (Celsius)")

    if opition == 3 :
        Celsius = float(input("How much Celsius? "))

        if Celsius < -273.15 :
            print("ERROR! Kelvin doesn't go Negitive! Pick a Higher Number.")
            Celsius = float(input("How much Celsius? "))
            print(str(CelsiusToKelvin(Celsius))+"K (Kelvin)")
        else:
            print(str(CelsiusToKelvin(Celsius))+"K (Kelvin)")