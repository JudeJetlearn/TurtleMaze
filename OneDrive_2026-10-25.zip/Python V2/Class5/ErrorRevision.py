num1 = 1
num2 = 1

try:

    result = num1 / num2

    num3 = int(input("Enter a Number. "))
    num4 = int(input("Enter a Number. "))

    print(num3+num4)

except ZeroDivisionError :
    print("Division by Zero is Illegal!")

except ValueError :
    print("Invalid Value! Enter a number.")
