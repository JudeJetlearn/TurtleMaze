import turtle
import random
import time

turtle.colormode(255)

screen = turtle.Screen()
screen.setup(width = 800, height = 600)  
screen.bgcolor("black")             

Turtle = turtle.Turtle()
Turtle.shape("turtle")
Turtle.speed(0)
Turtle.color(255,255,255)

starting_Time = time.time()

for i in range(random.randint(25,50)):

    r = random.randint(0,255)
    g = random.randint(0,255)
    b = random.randint(0,255)

    Turtle.color(r,g,b)
    Turtle.begin_fill()

    Turtle.circle(random.randint(25,250))
    Turtle.penup()
    Turtle.goto(random.randint(-400,400),random.randint(-300,300))
    Turtle.pendown()
    Turtle.end_fill()

    time.sleep(0.25)
    Turtle.clear()

ending_Time = time.time()

Duration = ending_Time - starting_Time
Duration = round(Duration)

Turtle.penup()
Turtle.goto(0,0)
Turtle.pendown()

Turtle.write(f"Time taken: {Duration} seconds", font = ("Times New Roman",20,"bold") )

turtle.mainloop()