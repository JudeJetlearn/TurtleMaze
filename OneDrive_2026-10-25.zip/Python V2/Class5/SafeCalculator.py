def Calculator():

    print("Welcome to Safe Calculator!")

    try:

        operation = input("Enter the operation to use! ( +, -, * and / ) ")

        if operation == "+" :

            print("SELECTED ADDITION:")

            try:
                 
                num1 = float(input("Enter the First Number to ADD. "))
                num2 = float(input("Enter the Second Number to ADD. "))
                print(f"{num1}{" + "}{num2}{" ="}")

                print(num1 + num2)

            except ValueError:
                print("Invalid Value! Please enter a valid number.")

        elif operation == "-" :
            
            print("SELECTED SUBTRACTION:")

            try:
                 
                num1 = float(input("Enter the First Number to SUBTRACT. "))
                num2 = float(input("Enter the Second Number to SUBTRACT. "))
                print(f"{num1}{" - "}{num2}{" ="}")
            
                print(num1 - num2)

            except ValueError:
                print("Invalid Value! Please enter a valid number.")

        elif operation == "*" :
                    
            print("SELECTED Multipication:")

            try:
                
                num1 = float(input("Enter the First Number to Multiply. "))
                num2 = float(input("Enter the Second Number to Multiply. "))
                print(f"{num1}{" x "}{num2}{" ="}")
            
                print(num1 * num2)

            except ValueError:
                print("Invalid Value! Please enter a valid number.")

        elif operation == "/" :
                            
            print("SELECTED Division:")

            try:
                            
                num1 = float(input("Enter the First Number to Divide. "))
                num2 = float(input("Enter the Second Number to Divide. "))
                print(f"{num1}{" ÷ "}{num2}{" ="}")
                            
                print(num1 / num2)

            except ZeroDivisionError:
                print("Math Error! You cant divide by Zero.")
            except ValueError:
                print("Invalid Value! Please enter a valid number.")

        else:
            raise ValueError

    except ValueError as e:
        print("Invalid operation! Please enter a valid OPERATION.",e)

    Calculator()

Calculator()
