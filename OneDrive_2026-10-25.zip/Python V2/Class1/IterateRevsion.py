Apps = ["Youtube","FaceBook","GMail","X"]

print(Apps)
Elements = len(Apps)

for i in range(Elements):
    print(Apps[i])

for i in Apps:
    print(i)

   