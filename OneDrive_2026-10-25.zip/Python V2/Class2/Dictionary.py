dictionary = {
    "Apple" : "Red Fruit",
    "Car" : "Mode of Trasport",
}

print(dictionary["Car"])

dictionary["Watermelon"]="Big and juicey fruit"

print(dictionary)