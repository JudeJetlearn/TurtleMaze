import turtle
import random

turtle.colormode(255)

screen = turtle.Screen()
screen.setup(width = 800, height = 600)  
screen.bgcolor("black")             

Turtle = turtle.Turtle()
Turtle.shape("turtle")
Turtle.speed(0)
Turtle.color(255,255,255)

for i in range(4):
    Turtle.forward(5)
    Turtle.right(90)

Turtle.penup()
Turtle.goto(random.randint(-400,400),random.randint(-300,300))
Turtle.pendown()

for i in range(90):
    Turtle.forward(10)
    Turtle.right(4)

for i in range(random.randint(100,1000)):

    r = random.randint(0,255)
    g = random.randint(0,255)
    b = random.randint(0,255)

    Turtle.color(r,g,b)
    Turtle.begin_fill()

    Turtle.circle(random.randint(25,250))
    Turtle.penup()
    Turtle.goto(random.randint(-400,400),random.randint(-300,300))
    Turtle.pendown()
    Turtle.end_fill()

turtle.mainloop()