def CupsToGrams(cups):
    return cups*128 # 1 cup = 128g




while True:

    print("1) Convert Cups to Grams")
    print("2) Convert Cups to TeaSpoons")
    print("3) Convert Cups to TableSpoons")

    opition = int(input("Pick a Measurement."))

    if opition == 1 :
        cups = int(input("How many Cups?"))
        print(str(CupsToGrams(cups))+"g")

    if opition == 2 :
        cups = int(input("How many Cups?"))

    if opition == 3 :
        cups = int(input("How many Cups?"))
