import random

name1 = input("Enter your FIRST NAME... ").upper()
name2 = input("Enter your SURNAME NAME... ").upper()
fullName = (f"{name1} {name2}")
    
char1 = name1[1]
char2 = name2[1]
initials = f"{char1}{char2}"

numberID = random.randint(100,999)

ticket = f"{initials}{numberID}"

print()
print(f"Full Name: {fullName}")
print()
print(f"Here is your Ticket ID: {ticket}")