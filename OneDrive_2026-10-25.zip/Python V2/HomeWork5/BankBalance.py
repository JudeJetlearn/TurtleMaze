import random

def Bank():

    print("Welcome to the Bank! Select the options bellow.")
    print()
    Money = float(random.randint(100,250))

    while True:

        print("1) Show Bank Balance.")
        print("2) Transfer money into Bank.")
        print("3) Withdraw money from Bank.")
        print("4) Exit Bank Account.")

        
        try:
            option = int(input("Enter an option... "))
            print()
        except ValueError:
            print("Invalid input! Please enter an option!")
            continue


        if option == 1 :
            print("Current Balance:")
            print(f"£{Money:.2f}")
            print()

        elif option == 2 :
            try:
                add = float(input("Enter the amount of money to add: "))

                if add < 0:
                    raise ValueError("Cannot transfer in a negative amount of money!")
            
                Money += add
                print("Money transferred in successfully!")
                print()
        
            except ValueError as e:
                print(f"{e}")

        elif option == 3 :
            try:
                withdraw = float(input("Enter the amount of money to Withdraw: "))

                if withdraw < 0:
                    raise ValueError("Cannot withdraw a negative amount of money!")
                elif withdraw > Money:
                    raise ValueError("Cannot transfer out more money than avalible!")
                    
                Money -= withdraw
                print("Money Withdrawn successfully!")
                print()
                
            except ValueError as e:
                print(f"{e}")

        elif option == 4:

            print("Thank you for using the Bank. Goodbye!")
            break
            
        else:
            print("Invalid selection!")              
Bank()