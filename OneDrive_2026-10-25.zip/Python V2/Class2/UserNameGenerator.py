import random

Scharaters = ["-","!","£","$","%","_","<","&","*","@","-","+","/",".",",",";",":"]

fullName = input("Enter your FULL Name. ")
names = fullName.split()

len(names)
if len(names) < 2 :
    print("Invalid FullName, Please Enter Again!")
    fullName = input("Enter your FULL Name. ")
    names = fullName.split()

name1 = names[0]
name2 = names[1]
name2 = name2[::-1]
username = name1[0:3] + name2[-2:]

id = random.randint(0,999)
SC = random.choice(Scharaters)

Username = f"{username}{SC}{id}"

print()
print(Username)