Book = {
    "Apple" : "Red Fruit",
    "Car" : "A Vehicle"
}

while True:

    print("1) Show Dictionary ")
    print("2) Add Word To Dictionary ")
    print("3) Remove Word From Dictionary ")
    print("4) Retrive a Value From The Dictionary")
    print("5) Exit Dictionary")

    option = int(input("Pick an option "))
    print()

    if option == 1:
        for i in Book:
            print(i +" : "+ Book[i])

    if option == 2:
        word = input("Add the Word ")
        definition = input("Add the Definition ")
        Book[word]=definition
        print()

    if option == 3:
        detete = input("Enter word to delete ")
        del Book[detete]
        print()

    if option == 4:
        word2 = input("Enter the Word ")
        print(Book[word2])
        print()

    if option == 5:
        break
