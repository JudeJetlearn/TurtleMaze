task = []

while True:
    
    print("1) Show List")
    print("2) Add Task From List")
    print("3) Remove Task From List")
    print("4) Exit List")
    option = int(input("Pick an option."))

    if option == 1 :
        print(task)
    if option == 2 :
        added = input("Add the task.")
        task.append(added)
    if option == 3 :
        remove = input("Pick the task to Remove.")
        task.remove(remove)
    if option == 4 :
        break

