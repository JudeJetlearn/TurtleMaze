import turtle
import random
import time

screen = turtle.Screen()
screen.bgcolor("white")
screen.setup(width = 500, height = 500 )
Mazes = []

Maze = [
    "XXXXXXXXXXXXXXX",
    "X     C       X", 
    "XXXXXXXXXXXXX X",
    "X   XCX     X X",  
    "X X X X XXX X X",
    "X X      XC   X",  
    "X XXXXXXXXXXXXX",
    "X X  C  XF    X",  
    "X X XXX XXXXX X",
    "X   X   X   X X",  
    "XXXXX XXX X X X",
    "XC        X   X",
    "XXXXXXXXXXXXXXX"
]
Mazes.append(Maze)

Maze2 = [
    "XXXXXXXXXXXXXXX",
    "X   CX        X",  
    "X XXXXX XXXXX X",
    "X X     X     X",
    "X X XXX X XXX X",
    "X X C X X X   X",  
    "X XXX X X X XXX",
    "X     X X X  CX",  
    "XXXXX X X X XXX",
    "X     X   X   X",
    "X XXXXX XXXXX X",
    "XC       XC   FX",  
    "XXXXXXXXXXXXXXXX"
] 
Mazes.append(Maze2)

PMaze = random.choice(Mazes)

player = turtle.Turtle()
player.shape("turtle")
player.color("green")
player.speed(0)
player.penup()

blocks = []
ending = []
coins = []

def MazeMaker():
    for y in range(len(PMaze)):
        for x in range(len(PMaze[y])):
            charater = PMaze[y][x]
            screenX = -225 + (x * 24)
            screenY = 225 - (y * 24)
            if charater == "X":
                block = turtle.Turtle()
                block.shape("square")
                block.color("black")
                block.speed(0)
                block.penup()
                block.goto(screenX,screenY)
                blocks.append(block)
            if charater == "C":
                coin = turtle.Turtle()
                coin.shape("circle")
                coin.color("yellow")
                coin.speed(0)
                coin.penup()
                coin.goto(screenX,screenY)
                coins.append(coin)
            if charater == "F":
                end = turtle.Turtle()
                end.shape("circle")
                end.color("green")
                end.speed(0)
                end.penup()
                end.goto(screenX,screenY)
                ending.append(end)

GameOver = False
StartingTime = time.time()
Score = 0

def EndingColide():
    global GameOver
    for i in range(len(ending)):
        if player.distance(ending[i]) < 15:
            GameOver = True
            break

    if GameOver == True:
        screen.bye()
        EndingTime = time.time()
        Duration = EndingTime - StartingTime
        Duration = round(Duration)
        print(f"Welldone! You have solved the maze. Your score was: {Score}")
        print(f"Time taken: {Duration} seconds")

def CoinPickup():
    global Score
    for i in range(len(coins)):
        if player.distance(coins[i]) < 15:
            Score = Score + 1
            coins[i].hideturtle()
            coins.pop(i)
            break                 

def Player_Up():
    PlayerX = player.xcor()
    PlayerY = player.ycor() + 24
    move = True
    
    for i in range(len(blocks)):
        BlockX = blocks[i].xcor()
        BlockY = blocks[i].ycor()
        if PlayerX == BlockX and PlayerY == BlockY :
            move = False

    if move == True:
        player.goto(PlayerX,PlayerY)
        CoinPickup()
        EndingColide()

def Player_Down():
    PlayerX = player.xcor()
    PlayerY = player.ycor() - 24
    move = True
    
    for i in range(len(blocks)):
        BlockX = blocks[i].xcor()
        BlockY = blocks[i].ycor()
        if PlayerX == BlockX and PlayerY == BlockY :
            move = False

    if move == True:
        player.goto(PlayerX,PlayerY)
        CoinPickup()
        EndingColide()

def Player_Right():
    PlayerX = player.xcor() + 24
    PlayerY = player.ycor()
    move = True
    
    for i in range(len(blocks)):
        BlockX = blocks[i].xcor()
        BlockY = blocks[i].ycor()
        if PlayerX == BlockX and PlayerY == BlockY :
            move = False

    if move == True:
        player.goto(PlayerX,PlayerY)
        CoinPickup()
        EndingColide()
    
def Player_Left():
    PlayerX = player.xcor() - 24
    PlayerY = player.ycor()
    move = True
        
    for i in range(len(blocks)):
        BlockX = blocks[i].xcor()
        BlockY = blocks[i].ycor()
        if PlayerX == BlockX and PlayerY == BlockY :
            move = False
            
    if move == True:
        player.goto(PlayerX,PlayerY)
        CoinPickup()
        EndingColide()

screen.listen()
screen.onkey(Player_Up,"Up")
screen.onkey(Player_Down,"Down")
screen.onkey(Player_Right,"Right")
screen.onkey(Player_Left,"Left")

player.goto(-201,201)
MazeMaker()
screen.mainloop()
