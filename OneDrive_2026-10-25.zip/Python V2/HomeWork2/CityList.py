city = []

while True:

    print()
    print("1) Show List")
    print("2) Add Task From List")
    print("3) Remove Task From List")
    print("4) Exit List")
    
    option = int(input("Pick an option. "))
    print()

    if option == 1 :
        for i in city:
            print(i)

    if option == 2 :
        added = input("Add the City. ").upper()
        city.append(added)

    if option == 3 :
        remove = input("Pick the City to Remove. ").upper()
        city.remove(remove)

    if option == 4 :
        break

    print()