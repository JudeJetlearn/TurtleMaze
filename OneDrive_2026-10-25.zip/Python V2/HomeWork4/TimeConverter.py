def HoursToMinutes(hours):
    return hours*60

def MinutesToSeconds(minutes):
    return minutes*60

def SecondsToHours(seconds):
    return seconds/3600


while True :
    print("1) Convert Hours to Minutes. ")
    print("2) Convert Minutes to Seconds. ")
    print("3) Convert Seconds to Hours. ")

    opition = int(input("Pick a Time Conversion. "))

    if opition == 1 :
        hours = float(input("How many Hours? "))
        print(str(HoursToMinutes(hours))+" Minutes")

    if opition == 2 :
        minutes = float(input("How many Minutes? "))
        print(str(MinutesToSeconds(minutes))+" Seconds")

    if opition == 3 :
        seconds = float(input("How many Seconds? "))
        print(str(SecondsToHours(seconds))+" Hours")